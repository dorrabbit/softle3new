(* typing.ml *)
open Syntax

exception Error of string

let err s = raise (Error s)

(* Type Environment *)
type tyenv = ty Environment.t

type subst = (tyvar * ty) list
  
let ty_prim op ty1 ty2 = match op with
    Plus -> (match ty1, ty2 with
               TyInt, TyInt -> TyInt
             | _ -> err ("Argument must be integer: +"))
  | Mult -> (match ty1, ty2 with
               TyInt, TyInt -> TyInt
             | _ -> err ("Argument must be integer: *"))
  | Lt -> (match ty1, ty2 with
               TyInt, TyInt -> TyBool
             | _ -> err ("Argument must be integer: <"))
  | Mt -> (match ty1, ty2 with
               TyInt, TyInt -> TyBool
             | _ -> err ("Argument must be integer: >"))
  | And -> (match ty1, ty2 with
               TyBool, TyBool -> TyBool
             | _ -> err ("Argument must be boolean: &&"))
  | Or -> (match ty1, ty2 with
               TyBool, TyBool -> TyBool
             | _ -> err ("Argument must be boolean: ||"))
      
(*| _ -> err "Not Implemented!"*)

let rec ty_exp tyenv = function
    Var x ->
      (try Environment.lookup x tyenv with
          Environment.Not_bound -> err ("variable not bound: " ^ x))
  | ILit _ -> TyInt
  | BLit _ -> TyBool
  | BinOp (op, exp1, exp2) ->
     let tyarg1 = ty_exp tyenv exp1 in
     let tyarg2 = ty_exp tyenv exp2 in
     ty_prim op tyarg1 tyarg2
  | IfExp (exp1, exp2, exp3) ->
     let tytest = ty_exp tyenv exp1 in
     if (tytest!=TyBool)
     then err ("Argument must be boolean: 1st argument of if")
     else
     let tyexp2 = ty_exp tyenv exp2 in
     let tyexp3 = ty_exp tyenv exp3 in
     if (tyexp2!=tyexp3)
     then err ("Arguments must be same type: 2nd and 3rd arguments of if")
     else tyexp2
  | LetExp (id, exp1, exp2) ->
     let tyvalue = ty_exp tyenv exp1 in
     ty_exp (Environment.extend id tyvalue tyenv) exp2
  | _ -> err ("Not Implemented!")

let ty_decl tyenv = function
    Exp e -> ty_exp tyenv e
  | _ -> err ("Not Implemented")

let rec subst_type sb ty =
  match sb with
  | [] -> ty
  | x :: tl -> (match ty with
      TyInt -> ty
    | TyBool -> ty
    | TyVar var -> if (fst x)=var then subst_type tl (snd x)
                                  else subst_type tl ty
    | TyFun (tya, tyb) ->
       (if TyVar (fst x)=tya then
           (if TyVar (fst x)=tyb
	    then subst_type tl (TyFun ((snd x), (snd x)))
	    else subst_type tl (TyFun ((snd x), tyb)))
        else if TyVar (fst x)=tyb
	     then subst_type tl (TyFun (tya, (snd x)))
	else subst_type tl ty))

let eqs_of_subst s = List.map (fun sx -> (TyVar (fst sx), snd sx)) s

let subst_eqs s eqs = List.map (fun (eqsxf, eqsxs) -> (subst_type s eqsxf, subst_type s eqsxs)) eqs
     
let rec unify l = match l with
    [] -> []
  | (tya, tyb) :: tl ->
     if tya=tyb then unify tl
     else match (tya, tyb) with
       (TyFun(ty11, ty12), TyFun(ty21, ty22)) ->
	 unify ((ty11, ty21) :: (ty12, ty22) :: tl)
     | (TyVar alpha, ty) ->
	if MySet.member alpha (freevar_ty ty) (* ty内にalphaがあるかどうか *)
	  then err ("Type error")
	  else (* ペアの両方にsubst_type α→tyするような関数 *)
	       (alpha, ty) :: unify (subst_eqs [(alpha, ty)] tl)
     | (ty, TyVar alpha) ->
	  if MySet.member alpha (freevar_ty ty)
	  then err ("Type error")
	  else (alpha, ty) :: unify (subst_eqs [(alpha, ty)] tl)
     | _ -> err("Type error")
